/**
 * 
 */
/**
 * @author fefodev
 *
 */
module GOLPack {
}