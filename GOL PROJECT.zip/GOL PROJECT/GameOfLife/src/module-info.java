/**
 * 
 */
/**
 * @author fefodev
 *
 */
module GameOfLife {
}